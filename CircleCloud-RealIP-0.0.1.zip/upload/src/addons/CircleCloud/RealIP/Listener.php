<?php

namespace CircleCloud\RealIP;

class Listener
{
    public static $options;
    public static function appSetup()
    {
        static::$options = \XF::options();
        if(isset(static::$options->customRealIpHeader)) {
            $customHeader = 'HTTP_'.(static::$options->customRealIpHeader ?: 'X_REAL_IP');
            if(isset($_SERVER[$customHeader])) {
                if(static::checkProxyIp() && $realIp = static::validateIp($_SERVER[$customHeader])) {
                    $_SERVER['REMOTE_ADDR'] = $realIp;
                }
            }
        }
    }

    private static function checkProxyIp()
    {
        if(!isset(static::$options->trustedProxyIp) || !static::$options->trustedProxyIp) {
            // 如果未设置地址 则代理地址必须为内网私有地址 即返回 false
            return !filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE);
        }
        return static::$options->trustedProxyIp == '0.0.0.0'
        || static::$options->trustedProxyIp == $_SERVER['REMOTE_ADDR'];
    }

    private static function validateIp($ip)
    {
        foreach (explode(',', $ip) as $ip) {
            if ((bool) filter_var(
                $ip,
                FILTER_VALIDATE_IP,
                FILTER_FLAG_IPV4 |
                FILTER_FLAG_IPV6 |
                FILTER_FLAG_NO_PRIV_RANGE |
                FILTER_FLAG_NO_RES_RANGE
            )) {
                return $ip;
            }
        }
        return null;
    }
}
