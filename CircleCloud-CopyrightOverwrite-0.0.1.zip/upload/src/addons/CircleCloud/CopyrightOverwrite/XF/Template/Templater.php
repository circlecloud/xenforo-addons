<?php

namespace CircleCloud\CopyrightOverwrite\XF\Template;

class Templater extends XFCP_Templater
{
    public function fnCopyright($templater, &$escape)
    {
        return \XF::phrase('copyright_overwrite');
    }
}
