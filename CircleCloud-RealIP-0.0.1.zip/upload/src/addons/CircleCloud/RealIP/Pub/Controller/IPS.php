<?php

namespace CircleCloud\RealIP\Pub\Controller;

use XF\Pub\Controller\AbstractController;
use XF\Mvc\ParameterBag;
use XF\Entity\User;
use XF\Util\Ip;

class IPS extends AbstractController
{
    public function actionIndex(ParameterBag $params)
    {
        $user = \XF::visitor();
        if(!$user->isLo) {
            return $this->noPermission();
        }
        $repo = \XF::repository('XF:Ip');
        $ips = $repo->getIpsByUser($user->user_id, 20);
        foreach ($ips as $ip => $info) {
            $info['ip'] = Ip::convertIpBinaryToString($info['ip']);
            unset($ips[$ip]);
            $ips[$info['ip']] = $info;
        }
        $viewParams = [
            'ips' => $ips,
            'pageSelected' => 'recent_used_ips'
        ];
        return $this->view('CircleCloud\RealIP:IPS', 'recent_used_ips', $viewParams);
    }
}
